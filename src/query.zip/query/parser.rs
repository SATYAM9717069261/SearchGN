use crate::query::operator::{Operator,Word};
use crate::query::ast::AstNode;

pub fn parse_token_to_ast(tokens:&Vec<Token>){

    let mut operand_stk:VecDeque<AstNode> = VecDeque::new();
    let mut operator_stk:VecDeque<::Operator> = VecDeque::new();
    let mut root:AstNode = AstNode::new();

    for token in tokens.iter(){
        match token{
            Operator =>{
                if operator_stk.is_empty(){
                    operator_stk.push_back(token);
                }else{
                    let stk_front = operator_stk.back();
                    let stk_front_rank = stk_front.precedence();
                    let token_rank = token.precedence();
                    if stk_front_rank > token_rank{
                        let Some(_) = operator_stk.pop_back().expect("stack is EMpty");
                        match stk_front{
                            OperatorType::Binary => {
                                let operand1  = operand_stk.back();
                                let Some(_) = operand_stk.pop_back().expect("stack is EMpty");

                                let operand2  = operand_stk.back();
                                let Some(_) = operand_stk.pop_back().expect("stack is EMpty");

                                operand_stk.push_back(
                                    AstNode::Binary{
                                        operator: stk_front,
                                        left: Box::new(operand1),
                                        right: Box::new(operand2)
                                    }
                                );
                            },
                            OperatorType::Unary => {
                                let operand1  = operand_stk.front();
                                let Some(_) = operand_stk.pop_front().expect("stack is EMpty");
                                operand_stk.push_back(
                                    AstNode::Unary{
                                        operator: stk_front,
                                        child: Box::new(operand1)
                                    }
                                );
                            }
                        }

                    }else{
                        operator_stk.push_back(token);
                    }
                }
            },
            _ => {
                operand_stk.push_back(AstNode::Word(token.clone()));
            }
        }
    }

}
